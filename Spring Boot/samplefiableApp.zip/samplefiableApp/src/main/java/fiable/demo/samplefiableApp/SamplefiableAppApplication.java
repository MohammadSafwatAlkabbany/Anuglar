package fiable.demo.samplefiableApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamplefiableAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamplefiableAppApplication.class, args);
	}

}
