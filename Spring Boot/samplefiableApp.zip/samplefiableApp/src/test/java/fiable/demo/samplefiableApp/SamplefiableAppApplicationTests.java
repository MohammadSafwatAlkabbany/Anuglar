package fiable.demo.samplefiableApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamplefiableAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
